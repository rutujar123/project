function openChat() 
{
    const chatModel = document.querySelector('.chat-model');
    chatModel.style.display = 'flex'; // Show the chat model
}

function closeChat()
 {
    const chatModel = document.querySelector('.chat-model');
    chatModel.style.display = 'none'; // Hide the chat model
}
